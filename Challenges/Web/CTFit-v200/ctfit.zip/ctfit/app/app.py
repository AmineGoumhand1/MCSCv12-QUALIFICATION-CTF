from flask import render_template,render_template_string,Flask,request, redirect, url_for
from urllib.parse import urlparse
import urllib.request
import random
import os
import subprocess
import base64
app=Flask(__name__)
app.secret_key=os.urandom(16)
challnumber=1
@app.route('/',methods=['GET','POST'])
def home():
    if request.method=='GET':
        return render_template('home.html')
    if request.method=='POST':
        try:
            url=request.form.get('url')
            scheme=urlparse(url).scheme
            hostname=urlparse(url).hostname
            blacklist_scheme=['file','gopher','php','ftp','dict','data']
            blacklist_hostname = [
    "127.0.0.1", 
    "localhost", 
   '0.0.0.0','::1','::ffff:127.0.0.1'
]

            if scheme in blacklist_scheme:
                return render_template_string('##########################################################################################################################')     
            if hostname in blacklist_hostname:
                return render_template_string('##########################################################################################################################')
            t=urllib.request.urlopen(url)
            content = t.read()
            output=base64.b64encode(content)
            return  redirect(url_for('order', data=output))
        except Exception as e:
                print(e)
                return f" An error occurred: {e}"
 


    
@app.route('/order')
def orderit():

    remote_addr = request.remote_addr
    

    if remote_addr in ['127.0.0.1', 'localhost']:
        cmd=request.args.get('cmd')
        challnumber=2555

        challnumber=request.args.get('challnumber')
        cmd_blacklist=['cat','/','.','"','\'','bash','bunzip2','bzcat','bzcmp','bzdiff','bzegrep','bzexe','bzfgrep','bzgrep','bzip2','bzip2recover','bzless','bzmore','chgrp','chmod','chown','cp','dash','date','dd','df','dmesg','dnsdomainname','domainname','echo','egrep','false','fgrep','findmnt','grep','gunzip','gzexe','gzip','hostname','kill','ln','login','lsblk','mkdir','mknod','mktemp','more','mount','mountpoint','mv','nisdomainname','pidof','ps','rbash','readlink','rm','rmdir','sed','sh','sleep','stty','su','sync','tar','tempfile','touch','true','umount','uname','uncompress','vdir','wdctl','ypdomainname','zcat','zcmp','zdiff','zegrep','zfgrep','zforce','zgrep','zless','zmore','znew','printenv','env','export','python','curl','|','||','self','rcat','perl','import','socat','base64','eval','$','`',

    "open", "file", "eval", "exec", "compile", "input", "__import__", "getattr", "setattr", 
    "delattr", "globals", "locals", "vars",

    "cat", "less", "more", "nano", "vi", "vim", "head", "tail", "strings", "grep", "awk", "sed", "od", "hexdump", "xxd",


    "touch", "find", "readlink", "realpath", "stat", "dir", "tree",


    "os", "subprocess", "shutil", "pathlib", "sys", "pickle", "marshal", "pty", "resource", 
    "fcntl", "posix", "tarfile", "zipfile", "base64", "nc", "socat", "'",'"'

]
       
        for i in cmd_blacklist:
            if i in cmd:
                return render_template_string('Sirawa sir tl3ab')
        print(f"Executing: {cmd}")
        res= subprocess.run(cmd, shell=True, capture_output=True, text=True)
        return res.stdout
    else:

        return render_template_string("Wa sf Hayd")
    
@app.route('/here-is-your-order')
def order():
    data = request.args.get('data', '')
    
    return render_template_string(f'''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>CTF Challenge</title>
        <style>
            body {{
                font-family: 'Arial', sans-serif;
                background-color: #0f172a;
                color: #fff;
                margin: 0;
                padding: 0;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                text-align: center;
            }}

            h1 {{
                color: #60a5fa;
                font-size: 2.5rem;
                margin-bottom: 1rem;
            }}

            pre {{
                background-color: #1e293b;
                padding: 1.5rem;
                border-radius: 10px;
                border: 1px solid #334155;
                color: #94a3b8;
                font-size: 1.2rem;
                max-width: 600px;
                margin: 0 auto;
                overflow-x: auto;
            }}

            .challenge-info {{
                margin-top: 1.5rem;
                font-size: 1rem;
                color: #4ade80;
            }}
        </style>
    </head>
    <body>
        <div>
            <h1>Encoded Challenges :</h1>
            <pre>Challenge {data[:challnumber]}...</pre>
            <div class="challenge-info">
               DO DO 
            </div>
        </div>
    </body>
    </html>
    ''')

if __name__=="__main__":
    app.run(host='0.0.0.0',port='5000')
